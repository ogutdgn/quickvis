const CONFIG = {
  CLIENT_ID: 'Ov23liEPqc4XAqT5VB1Q',
  PROXY_SERVER_URL: 'https://quickvis-oauth-proxy.vercel.app',
  SCOPES: 'repo user',
  AUTH_URL: 'https://github.com/login/oauth/authorize',
  API_BASE: 'https://api.github.com'
};
