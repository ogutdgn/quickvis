export const CONFIG = {
  CLIENT_ID: 'Ov23lieBdpAuzLEPM61t',
  PROXY_SERVER_URL: 'https://quickvis.vercel.app/',
  SCOPES: 'repo user',
  AUTH_URL: 'https://github.com/login/oauth/authorize',
  API_BASE: 'https://api.github.com'
};
